#посылка 33698023
def hasCycle(head):
    node_set = []
    while head.next:
        if head in node_set:
            return True
        node_set.append(head)
        head = head.next
    return False
